
package model;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.LinkedList;
import java.util.List;

public class NoticiaDao {
    private PreparedStatement comando;
    private ResultSet resultado;
    //crud
    
    public boolean addNoticia(Noticia noticia){
     try{ 
        comando = getConexao().prepareStatement
      ("INSERT INTO NOTICIAS VALUES (?,?,?,?,?,?,?)");
       comando.setInt(1, noticia.getId());
       comando.setString(2, noticia.getAutor());
       comando.setDate(3, noticia.getData_pb());
       comando.setString(4, noticia.getAssunto());
       comando.setString(5, noticia.getTitulo());
       comando.setString(6, noticia.getTexto());
       comando.setInt(7, 1);
       comando.execute();
        return true;
     }
     catch (Exception e){
         return false;
     }
    }
    
    
   public boolean updateNoticia(Noticia noticia){
      try{ 
        comando = getConexao().prepareStatement
      ("UPDATE NOTICIAS SET "
              + "AUTOR=?,"
              + "DATA_PB=?,"
              + "ASSUNTO=?,"
              + "TITULO=?,"
              + "TEXTO=? "
              + "WHERE ID=?");
      
       comando.setString(1, noticia.getAutor());
       comando.setDate(2, noticia.getData_pb());
       comando.setString(3, noticia.getAssunto());
       comando.setString(4, noticia.getTitulo());
       comando.setString(5, noticia.getTexto());
        comando.setInt(6, noticia.getId());
       comando.execute();
        return true;
     }
     catch (Exception e){
         return false;
     }
          
    }
     
  public boolean deleteNoticia(Integer id){
     try{ 
        comando = getConexao().prepareStatement
        ("DELETE FROM NOTICIAS WHERE ID=?");      
       comando.setInt(1, id);      
       comando.execute();
        return true;
     }
     catch (Exception e){
         return false;
     }
    }
     
   public Noticia getNoticia (Integer id){
      try{ 
        comando = getConexao().prepareStatement
           ("SELECT * FROM NOTICIAS WHERE ID=?");      
       comando.setInt(1, id);      
       resultado = comando.executeQuery();
       if (resultado.next()){
           Noticia noticia = new Noticia();
           noticia.setId(resultado.getInt(1));
           noticia.setAutor(resultado.getString(2));
           noticia.setData_pb(resultado.getDate(3));
           noticia.setAssunto(resultado.getString(4));
           noticia.setTitulo(resultado.getString(5));
           noticia.setTexto(resultado.getString(6));
           return noticia;
       }
       else{
           return null;
       }
        
     }
     catch (Exception e){
         return null;
     }
     }
     
      public List<Noticia> getListNoticias (){
        List<Noticia> listaNoticias;
        listaNoticias = new LinkedList<Noticia>();
         try{ 
            comando = getConexao().prepareStatement
               ("SELECT * FROM NOTICIAS");  
           resultado = comando.executeQuery();
           while (resultado.next()){
               Noticia noticia = new Noticia();
               noticia.setId(resultado.getInt(1));
               noticia.setAutor(resultado.getString(2));
               noticia.setData_pb(resultado.getDate(3));
               noticia.setAssunto(resultado.getString(4));
               noticia.setTitulo(resultado.getString(5));
               noticia.setTexto(resultado.getString(6));
               listaNoticias.add(noticia);
           }
           return listaNoticias;
         }
         catch (Exception e){
             return null;
         }
     }
      
       public List<Noticia> getListNoticiasByAutor (String autor){
             List<Noticia> listaNoticias;
        listaNoticias = new LinkedList<Noticia>();
         try{ 
            comando = getConexao().prepareStatement
               ("SELECT * FROM NOTICIAS WHERE AUTOR=?"); 
            comando.setString(1, autor);
           resultado = comando.executeQuery();
           while (resultado.next()){
               Noticia noticia = new Noticia();
               noticia.setId(resultado.getInt(1));
               noticia.setAutor(resultado.getString(2));
               noticia.setData_pb(resultado.getDate(3));
               noticia.setAssunto(resultado.getString(4));
               noticia.setTitulo(resultado.getString(5));
               noticia.setTexto(resultado.getString(6));
               listaNoticias.add(noticia);
           }
           return listaNoticias;
         }
         catch (Exception e){
             return null;
         }
      
       }
     
     //método privado
      private Connection getConexao(){
         Connection conexao;
         try{
             Class.forName("org.postgresql.Driver");
             conexao = DriverManager.getConnection
             ("jdbc:postgresql://127.0.0.1:5432/programacao4", 
               "postgres",
                "1234");
             
              return conexao;
         } 
         catch(Exception e){
             System.out.println("Erro de conexão");
             return null;
         }
      }
      
    
    
    
}

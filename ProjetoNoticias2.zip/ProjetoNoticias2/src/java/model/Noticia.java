package model;

import java.io.InputStream;
import java.sql.Date;

public class Noticia {
    private Integer id;
    private String autor;
    private Date data_pb;
    private String assunto;
    private String titulo;
    private String texto;
    private InputStream imagem;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getAutor() {
        return autor;
    }

    public void setAutor(String autor) {
        this.autor = autor;
    }

    public Date getData_pb() {
        return data_pb;
    }

    public void setData_pb(Date data_pb) {
        this.data_pb = data_pb;
    }

    public String getAssunto() {
        return assunto;
    }

    public void setAssunto(String assunto) {
        this.assunto = assunto;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public String getTexto() {
        return texto;
    }

    public void setTexto(String texto) {
        this.texto = texto;
    }

    public InputStream getImagem() {
        return imagem;
    }

    public void setImagem(InputStream imagem) {
        this.imagem = imagem;
    }
    
    
    
}
